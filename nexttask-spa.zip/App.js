// importar os arquivos com as rotas
import Routes from "./src/routes/routes";

const App = () => {
  // carregar o arquivo de rotas
  return <Routes/>;
}

export default App;